export const WEAPON_IMAGES = {
  sword: "https://images.unsplash.com/photo-1589223987351-5c5d76982b8e?auto=format&fit=crop&q=80", // Roman sword
  axe: "https://images.unsplash.com/photo-1548517231-3152f67fc182?auto=format&fit=crop&q=80", // Battle axe
  spear: "https://images.unsplash.com/photo-1578985545062-69928b1d9587?auto=format&fit=crop&q=80", // Long spear
  bow: "https://images.unsplash.com/photo-1541742425281-9d5a45c3c38e?auto=format&fit=crop&q=80", // Archery bow
  shield: "https://images.unsplash.com/photo-1546182990-dffeafbe841d?auto=format&fit=crop&q=80", // Medieval shield
  dagger: "https://images.unsplash.com/photo-1577371280312-65a77cdc2af5?auto=format&fit=crop&q=80", // Ornate dagger
  mace: "https://images.unsplash.com/photo-1578321709315-d89d3bb4056f?auto=format&fit=crop&q=80" // Medieval mace
};

// Sort weapons chronologically for the timeline
export const SAMPLE_WEAPONS = [
  {
    id: 1,
    name: "Egyptian Khopesh",
    description: "A sickle-shaped sword that evolved from battle axes, used by Egyptian armies.",
    origin: "Ancient Egypt",
    period: "Ancient (3000 BCE - 500 CE)",
    type: "Sword",
    imageUrl: WEAPON_IMAGES.sword,
    specifications: "Length: 50-60cm, Curved bronze blade",
    historicalContext: "The khopesh was a symbol of royal power in ancient Egypt and was effective against shields."
  },
  {
    id: 2,
    name: "Greek Dory Spear",
    description: "The primary weapon of Greek hoplites, used in the famous phalanx formation.",
    origin: "Ancient Greece",
    period: "Ancient (3000 BCE - 500 CE)",
    type: "Spear",
    imageUrl: WEAPON_IMAGES.spear,
    specifications: "Length: 2.4m, Weight: 2kg, Iron spearhead with bronze socket",
    historicalContext: "The dory and phalanx formation were key to Greek military dominance in the classical period."
  },
  {
    id: 3,
    name: "Hoplon Shield",
    description: "The iconic round shield of Greek hoplites, essential to phalanx warfare.",
    origin: "Ancient Greece",
    period: "Ancient (3000 BCE - 500 CE)",
    type: "Shield",
    imageUrl: WEAPON_IMAGES.shield,
    specifications: "Diameter: 90cm, Weight: 7kg, Bronze-faced wood construction",
    historicalContext: "The hoplon shield was crucial to Greek warfare, allowing soldiers to protect both themselves and their neighbors in formation."
  },
  {
    id: 4,
    name: "Roman Gladius",
    description: "The primary sword of the Roman legions, known for its effectiveness in close combat.",
    origin: "Ancient Rome",
    period: "Ancient (3000 BCE - 500 CE)",
    type: "Sword",
    imageUrl: WEAPON_IMAGES.sword,
    specifications: "Length: 60-85cm, Weight: 1.5kg, Double-edged blade",
    historicalContext: "The gladius was the main weapon of Roman legionaries, used extensively throughout the Roman Empire's expansion."
  },
  {
    id: 5,
    name: "Roman Pugio",
    description: "A dagger carried by Roman legionaries as a sidearm and utility tool.",
    origin: "Ancient Rome",
    period: "Ancient (3000 BCE - 500 CE)",
    type: "Dagger",
    imageUrl: WEAPON_IMAGES.dagger,
    specifications: "Length: 18-28cm, Double-edged blade",
    historicalContext: "The pugio was both a backup weapon and a practical tool for Roman soldiers."
  },
  {
    id: 6,
    name: "Viking Battle Axe",
    description: "A versatile weapon favored by Norse warriors, effective against shields and armor.",
    origin: "Scandinavia",
    period: "Medieval (500 - 1500)",
    type: "Axe",
    imageUrl: WEAPON_IMAGES.axe,
    specifications: "Length: 90-120cm, Weight: 2.5kg, Single-edged head",
    historicalContext: "Viking axes were both weapons and tools, symbolizing the practical nature of Norse warfare and exploration."
  },
  {
    id: 7,
    name: "Mongol Composite Bow",
    description: "A sophisticated recurve bow that gave Mongol armies their feared reputation for mounted archery.",
    origin: "Mongolia",
    period: "Medieval (500 - 1500)",
    type: "Bow",
    imageUrl: WEAPON_IMAGES.bow,
    specifications: "Draw weight: 100-160lbs, Range: 300m, Composite construction",
    historicalContext: "The Mongol bow was crucial in establishing the largest contiguous land empire in history."
  },
  {
    id: 8,
    name: "War Mace",
    description: "A heavy blunt weapon designed to crush armor and shields, popular among medieval knights.",
    origin: "Western Europe",
    period: "Medieval (500 - 1500)",
    type: "Mace",
    imageUrl: WEAPON_IMAGES.mace,
    specifications: "Length: 60cm, Weight: 2.5kg, Steel head with flanges",
    historicalContext: "Maces became increasingly popular as plate armor made cutting weapons less effective."
  },
  {
    id: 9,
    name: "Crusader's Dagger",
    description: "A long dagger used as both a backup weapon and a tool by medieval knights.",
    origin: "Western Europe",
    period: "Medieval (500 - 1500)",
    type: "Dagger",
    imageUrl: WEAPON_IMAGES.dagger,
    specifications: "Length: 30-40cm, Double-edged blade, Cruciform hilt",
    historicalContext: "These daggers were essential tools for knights, used for everything from dining to delivering the coup de grace."
  },
  {
    id: 10,
    name: "Persian Shamshir",
    description: "A curved sword with exceptional cutting ability, the pride of Persian cavalry.",
    origin: "Persia",
    period: "Medieval (500 - 1500)",
    type: "Sword",
    imageUrl: WEAPON_IMAGES.sword,
    specifications: "Length: 90cm, Curved blade, Pronounced curve",
    historicalContext: "The shamshir's design influenced swords across the Islamic world and beyond."
  },
  {
    id: 11,
    name: "Chinese Qiang Spear",
    description: "A versatile spear known for its leaf-shaped blade and red horse-hair tassel.",
    origin: "China",
    period: "Medieval (500 - 1500)",
    type: "Spear",
    imageUrl: WEAPON_IMAGES.spear,
    specifications: "Length: 2-3m, Weight: 1.8kg, Steel blade with red tassel",
    historicalContext: "The qiang was one of the four major weapons in Chinese martial arts, alongside the staff, saber, and sword."
  },
  {
    id: 12,
    name: "Samurai Yumi",
    description: "An asymmetrical longbow used by Japanese samurai, known for its exceptional range.",
    origin: "Japan",
    period: "Medieval (500 - 1500)",
    type: "Bow",
    imageUrl: WEAPON_IMAGES.bow,
    specifications: "Length: 2.2m, Asymmetrical design, Composite construction",
    historicalContext: "The yumi was the primary weapon of samurai before the widespread adoption of the katana."
  },
  {
    id: 13,
    name: "Italian Rapier",
    description: "An elegant thrusting sword developed for civilian self-defense and dueling.",
    origin: "Italy",
    period: "Renaissance (1300 - 1600)",
    type: "Sword",
    imageUrl: WEAPON_IMAGES.sword,
    specifications: "Length: 104cm, Weight: 1kg, Narrow blade with complex hilt",
    historicalContext: "The rapier symbolized the renaissance gentleman and the art of fencing."
  },
  {
    id: 14,
    name: "Landsknecht Zweihänder",
    description: "A massive two-handed sword used by German mercenaries.",
    origin: "Germany",
    period: "Renaissance (1300 - 1600)",
    type: "Sword",
    imageUrl: WEAPON_IMAGES.sword,
    specifications: "Length: 150-180cm, Weight: 2-3.2kg, Double-edged blade",
    historicalContext: "The Zweihänder was a status symbol of the elite Landsknecht mercenaries."
  },
  {
    id: 15,
    name: "Main Gauche",
    description: "A left-handed dagger used in conjunction with the rapier.",
    origin: "Spain",
    period: "Renaissance (1300 - 1600)",
    type: "Dagger",
    imageUrl: WEAPON_IMAGES.dagger,
    specifications: "Length: 30-40cm, Ornate guard, Parrying blade",
    historicalContext: "This parrying dagger was essential in the complex fighting style of Renaissance sword fighting."
  }

];
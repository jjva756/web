import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import { motion, AnimatePresence } from "framer-motion";
import { ChevronDown, ChevronUp, Clock } from "lucide-react";
import { useState } from "react";
import type { Weapon } from "@shared/schema";
import { periods } from "@shared/schema";
import { Button } from "@/components/ui/button";

interface WeaponTimelineProps {
  weapons: Weapon[];
}

export function WeaponTimeline({ weapons }: WeaponTimelineProps) {
  const [expandedId, setExpandedId] = useState<number | null>(null);
  const [selectedPeriod, setSelectedPeriod] = useState<string | null>(null);

  // Sort weapons by period to ensure chronological order
  const sortedWeapons = [...weapons].sort((a, b) => {
    const periodOrder = {
      "Ancient (3000 BCE - 500 CE)": 1,
      "Medieval (500 - 1500)": 2,
      "Renaissance (1300 - 1600)": 3
    };
    return periodOrder[a.period as keyof typeof periodOrder] - periodOrder[b.period as keyof typeof periodOrder];
  });

  const filteredWeapons = selectedPeriod 
    ? sortedWeapons.filter(weapon => weapon.period === selectedPeriod)
    : sortedWeapons;

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold">Historical Timeline</h2>
        <div className="flex gap-2">
          {periods.map((period) => (
            <Button
              key={period}
              variant={selectedPeriod === period ? "default" : "outline"}
              onClick={() => setSelectedPeriod(selectedPeriod === period ? null : period)}
              className="text-sm"
            >
              <Clock className="w-4 h-4 mr-2" />
              {period.split(" ")[0]}
            </Button>
          ))}
        </div>
      </div>

      <div className="relative space-y-4 pl-4">
        <div className="absolute left-9 top-0 bottom-0 w-0.5 bg-border" />
        <AnimatePresence mode="popLayout">
          {filteredWeapons.map((weapon) => (
            <motion.div
              key={weapon.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
              className="relative"
              layout
            >
              <Collapsible
                open={expandedId === weapon.id}
                onOpenChange={() => setExpandedId(expandedId === weapon.id ? null : weapon.id)}
              >
                <div className="relative flex items-start gap-4">
                  <motion.div
                    className="absolute left-0 w-4 h-4 rounded-full bg-primary mt-2 cursor-pointer"
                    whileHover={{ scale: 1.2 }}
                    whileTap={{ scale: 0.9 }}
                    onClick={() => setExpandedId(expandedId === weapon.id ? null : weapon.id)}
                  />
                  <CollapsibleTrigger className="ml-12 w-full">
                    <Card className="hover:shadow-md transition-shadow cursor-pointer">
                      <CardHeader>
                        <div className="flex items-center justify-between">
                          <div>
                            <CardTitle className="text-xl">{weapon.name}</CardTitle>
                            <CardDescription className="text-sm">
                              {weapon.origin} • {weapon.period}
                            </CardDescription>
                          </div>
                          {expandedId === weapon.id ? (
                            <ChevronUp className="h-5 w-5 text-muted-foreground" />
                          ) : (
                            <ChevronDown className="h-5 w-5 text-muted-foreground" />
                          )}
                        </div>
                      </CardHeader>
                    </Card>
                  </CollapsibleTrigger>
                </div>

                <CollapsibleContent>
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    exit={{ opacity: 0, height: 0 }}
                    transition={{ duration: 0.3 }}
                    className="ml-16 mt-2"
                  >
                    <Card>
                      <CardContent className="pt-6">
                        <div className="grid md:grid-cols-2 gap-6">
                          <div className="space-y-4">
                            <p className="text-sm text-muted-foreground">{weapon.description}</p>
                            <div>
                              <h4 className="font-semibold mb-2">Specifications</h4>
                              <p className="text-sm">{weapon.specifications}</p>
                            </div>
                            <div>
                              <h4 className="font-semibold mb-2">Historical Context</h4>
                              <p className="text-sm">{weapon.historicalContext}</p>
                            </div>
                          </div>
                          <motion.div 
                            className="aspect-video relative rounded-lg overflow-hidden"
                            whileHover={{ scale: 1.02 }}
                            transition={{ duration: 0.2 }}
                          >
                            <img
                              src={weapon.imageUrl}
                              alt={weapon.name}
                              className="object-cover w-full h-full"
                            />
                          </motion.div>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                </CollapsibleContent>
              </Collapsible>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </div>
  );
}
import { Link } from "wouter";
import { Sword, Menu } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Sheet,
  SheetContent,
  SheetTrigger,
} from "@/components/ui/sheet";

export default function Navbar() {
  return (
    <nav className="bg-primary text-primary-foreground shadow-lg">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <Link href="/">
            <a className="flex items-center space-x-2 text-xl font-bold">
              <Sword className="h-6 w-6" />
              <span>Ancient Armory</span>
            </a>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex space-x-6">
            <Link href="/">
              <a className="hover:text-primary-foreground/80 transition-colors">
                Home
              </a>
            </Link>
            <Link href="/weapons">
              <a className="hover:text-primary-foreground/80 transition-colors">
                Weapons
              </a>
            </Link>
          </div>

          {/* Mobile Navigation */}
          <Sheet>
            <SheetTrigger asChild className="md:hidden">
              <Button variant="ghost" size="icon">
                <Menu className="h-6 w-6" />
              </Button>
            </SheetTrigger>
            <SheetContent>
              <div className="flex flex-col space-y-4 mt-8">
                <Link href="/">
                  <a className="text-lg font-medium hover:text-primary transition-colors">
                    Home
                  </a>
                </Link>
                <Link href="/weapons">
                  <a className="text-lg font-medium hover:text-primary transition-colors">
                    Weapons
                  </a>
                </Link>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </nav>
  );
}

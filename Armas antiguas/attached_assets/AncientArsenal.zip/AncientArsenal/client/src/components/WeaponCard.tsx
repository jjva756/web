import { Link } from "wouter";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import type { Weapon } from "@shared/schema";

interface WeaponCardProps {
  weapon: Weapon;
}

export function WeaponCard({ weapon }: WeaponCardProps) {
  return (
    <Link href={`/weapons/${weapon.id}`}>
      <Card className="cursor-pointer hover:shadow-lg transition-shadow">
        <div className="aspect-video relative">
          <img
            src={weapon.imageUrl}
            alt={weapon.name}
            className="object-cover w-full h-full rounded-t-lg"
          />
        </div>
        <CardHeader>
          <CardTitle>{weapon.name}</CardTitle>
          <CardDescription>{weapon.origin} • {weapon.period}</CardDescription>
        </CardHeader>
        <CardContent>
          <p className="line-clamp-2 text-muted-foreground">
            {weapon.description}
          </p>
        </CardContent>
      </Card>
    </Link>
  );
}

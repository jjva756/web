import { useQuery } from "@tanstack/react-query";
import { useParams } from "wouter";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import type { Weapon } from "@shared/schema";

export default function WeaponDetailPage() {
  const { id } = useParams();
  
  const { data: weapon, isLoading } = useQuery<Weapon>({
    queryKey: [`/api/weapons/${id}`],
  });

  if (isLoading) return <div>Loading...</div>;
  if (!weapon) return <div>Weapon not found</div>;

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="aspect-video relative rounded-lg overflow-hidden">
        <img
          src={weapon.imageUrl}
          alt={weapon.name}
          className="object-cover w-full h-full"
        />
      </div>

      <div className="space-y-6">
        <h1 className="text-4xl font-bold">{weapon.name}</h1>
        <p className="text-xl text-muted-foreground">{weapon.description}</p>

        <Separator />

        <Card>
          <CardHeader>
            <CardTitle>Specifications</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <h3 className="font-semibold">Type</h3>
                <p>{weapon.type}</p>
              </div>
              <div>
                <h3 className="font-semibold">Origin</h3>
                <p>{weapon.origin}</p>
              </div>
              <div>
                <h3 className="font-semibold">Period</h3>
                <p>{weapon.period}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Historical Context</CardTitle>
          </CardHeader>
          <CardContent>
            <p>{weapon.historicalContext}</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

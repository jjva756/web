import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Sword, Shield, History, Book } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { WeaponTimeline } from "@/components/WeaponTimeline";
import type { Weapon } from "@shared/schema";

export default function HomePage() {
  const { data: weapons } = useQuery<Weapon[]>({
    queryKey: ["/api/weapons"],
  });

  const featuredWeapons = weapons?.slice(0, 3) || [];

  return (
    <div className="space-y-16">
      {/* Hero Section */}
      <section className="text-center space-y-6 py-16">
        <h1 className="text-4xl md:text-6xl font-bold bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
          Discover Ancient Weapons
        </h1>
        <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
          Explore the fascinating world of pre-gunpowder weaponry from diverse cultures across history.
        </p>
        <Link href="/weapons">
          <Button size="lg" className="mt-4">
            Browse Collection
          </Button>
        </Link>
      </section>

      {/* Feature Cards */}
      <section className="grid md:grid-cols-3 gap-8">
        <Card className="p-6">
          <CardContent className="space-y-4 p-0">
            <Sword className="h-10 w-10 text-primary" />
            <h2 className="text-xl font-semibold">Diverse Arsenal</h2>
            <p className="text-muted-foreground">
              From Roman gladius to Japanese katana, discover weapons that shaped history.
            </p>
          </CardContent>
        </Card>

        <Card className="p-6">
          <CardContent className="space-y-4 p-0">
            <Book className="h-10 w-10 text-primary" />
            <h2 className="text-xl font-semibold">Cultural Context</h2>
            <p className="text-muted-foreground">
              Learn about the cultural significance and historical impact of each weapon.
            </p>
          </CardContent>
        </Card>

        <Card className="p-6">
          <CardContent className="space-y-4 p-0">
            <History className="h-10 w-10 text-primary" />
            <h2 className="text-xl font-semibold">Historical Timeline</h2>
            <p className="text-muted-foreground">
              Explore weapons across different eras and their evolution through time.
            </p>
          </CardContent>
        </Card>
      </section>

      {/* Featured Weapons */}
      <section className="space-y-8">
        <h2 className="text-3xl font-bold text-center">Featured Weapons</h2>
        <div className="grid md:grid-cols-3 gap-6">
          {featuredWeapons.map((weapon) => (
            <Link key={weapon.id} href={`/weapons/${weapon.id}`}>
              <Card className="cursor-pointer hover:shadow-lg transition-shadow overflow-hidden">
                <div className="aspect-video relative">
                  <img
                    src={weapon.imageUrl}
                    alt={weapon.name}
                    className="object-cover w-full h-full"
                  />
                </div>
                <CardContent className="p-4">
                  <h3 className="font-semibold text-lg">{weapon.name}</h3>
                  <p className="text-sm text-muted-foreground mt-2">
                    {weapon.origin} • {weapon.period}
                  </p>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </section>

      {/* Timeline Section */}
      {weapons && <WeaponTimeline weapons={weapons} />}
    </div>
  );
}
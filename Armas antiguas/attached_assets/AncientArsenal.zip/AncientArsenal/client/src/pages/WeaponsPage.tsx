import { useQuery } from "@tanstack/react-query";
import { WeaponCard } from "@/components/WeaponCard";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { weaponTypes } from "@shared/schema";
import type { Weapon } from "@shared/schema";

export default function WeaponsPage() {
  const { data: weapons, isLoading } = useQuery<Weapon[]>({
    queryKey: ["/api/weapons"],
  });

  if (isLoading) {
    return <div>Loading...</div>;
  }

  return (
    <div className="space-y-8">
      <h1 className="text-4xl font-bold">Ancient Weapons Collection</h1>
      
      <Tabs defaultValue="all">
        <TabsList>
          <TabsTrigger value="all">All</TabsTrigger>
          {weaponTypes.map((type) => (
            <TabsTrigger key={type} value={type.toLowerCase()}>
              {type}
            </TabsTrigger>
          ))}
        </TabsList>

        <TabsContent value="all" className="mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {weapons?.map((weapon) => (
              <WeaponCard key={weapon.id} weapon={weapon} />
            ))}
          </div>
        </TabsContent>

        {weaponTypes.map((type) => (
          <TabsContent key={type} value={type.toLowerCase()} className="mt-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {weapons
                ?.filter((w) => w.type.toLowerCase() === type.toLowerCase())
                .map((weapon) => (
                  <WeaponCard key={weapon.id} weapon={weapon} />
                ))}
            </div>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
}

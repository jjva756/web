import { pgTable, text, serial, integer, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const weapons = pgTable("weapons", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  origin: text("origin").notNull(),
  period: text("period").notNull(),
  type: text("type").notNull(),
  imageUrl: text("image_url").notNull(),
  specifications: text("specifications").notNull(),
  historicalContext: text("historical_context").notNull(),
});

export const insertWeaponSchema = createInsertSchema(weapons).pick({
  name: true,
  description: true,
  origin: true,
  period: true,
  type: true,
  imageUrl: true,
  specifications: true,
  historicalContext: true,
});

export type InsertWeapon = z.infer<typeof insertWeaponSchema>;
export type Weapon = typeof weapons.$inferSelect;

export const weaponTypes = [
  "Sword",
  "Spear",
  "Axe",
  "Bow",
  "Mace",
  "Dagger",
  "Shield",
] as const;

export const periods = [
  "Ancient (3000 BCE - 500 CE)",
  "Medieval (500 - 1500)",
  "Renaissance (1300 - 1600)",
] as const;

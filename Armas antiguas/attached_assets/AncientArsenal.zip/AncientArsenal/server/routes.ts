import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertWeaponSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  app.get("/api/weapons", async (_req, res) => {
    const weapons = await storage.getAllWeapons();
    res.json(weapons);
  });

  app.get("/api/weapons/:id", async (req, res) => {
    const weapon = await storage.getWeapon(parseInt(req.params.id));
    if (!weapon) {
      res.status(404).json({ message: "Weapon not found" });
      return;
    }
    res.json(weapon);
  });

  app.get("/api/weapons/type/:type", async (req, res) => {
    const weapons = await storage.getWeaponsByType(req.params.type);
    res.json(weapons);
  });

  const httpServer = createServer(app);
  return httpServer;
}

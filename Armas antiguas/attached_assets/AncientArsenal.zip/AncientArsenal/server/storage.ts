import { users, type User, type InsertUser } from "@shared/schema";
import { weapons, type Weapon, type InsertWeapon } from "@shared/schema";
import { SAMPLE_WEAPONS } from "../client/src/lib/constants";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getAllWeapons(): Promise<Weapon[]>;
  getWeapon(id: number): Promise<Weapon | undefined>;
  getWeaponsByType(type: string): Promise<Weapon[]>;
  createWeapon(weapon: InsertWeapon): Promise<Weapon>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private weapons: Map<number, Weapon>;
  currentId: number;

  constructor() {
    this.users = new Map();
    this.weapons = new Map();
    this.currentId = 1;

    // Initialize with sample data
    SAMPLE_WEAPONS.forEach(weapon => {
      this.weapons.set(weapon.id, weapon);
      this.currentId = Math.max(this.currentId, weapon.id + 1);
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getAllWeapons(): Promise<Weapon[]> {
    return Array.from(this.weapons.values());
  }

  async getWeapon(id: number): Promise<Weapon | undefined> {
    return this.weapons.get(id);
  }

  async getWeaponsByType(type: string): Promise<Weapon[]> {
    return Array.from(this.weapons.values()).filter(
      weapon => weapon.type.toLowerCase() === type.toLowerCase()
    );
  }

  async createWeapon(insertWeapon: InsertWeapon): Promise<Weapon> {
    const id = this.currentId++;
    const weapon: Weapon = { ...insertWeapon, id };
    this.weapons.set(id, weapon);
    return weapon;
  }
}

export const storage = new MemStorage();